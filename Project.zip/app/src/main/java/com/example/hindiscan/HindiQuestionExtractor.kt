package com.example.hindiscan

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class HindiQuestionExtractor(private val apiKey: String) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(45, TimeUnit.SECONDS)
        .readTimeout(180, TimeUnit.SECONDS)
        .build()

    suspend fun extract(
        text: String, subject: Subject, targetLang: String,
        defaultBoard: String, defaultYear: String
    ): List<Question> = withContext(Dispatchers.IO) {
        if (apiKey.isBlank() || text.isBlank()) return@withContext emptyList()
        val chunks = text.chunked(12000)
        val allQuestions = mutableListOf<Question>()

        for ((index, chunk) in chunks.withIndex()) {
            val prompt = buildStrictPrompt(chunk, subject, targetLang, defaultBoard, defaultYear, index + 1, chunks.size)
            allQuestions.addAll(callGemini(prompt))
        }

        return@withContext allQuestions
            .distinctBy { it.q.trim().lowercase() }
            .filter { q ->
                q.options.size == 4 && q.options.distinct().size == 4 &&
                q.options.none { it.isBlank() } && q.q.isNotBlank() && q.ans in 0..3
            }
    }

    private fun buildStrictPrompt(
        text: String, subject: Subject, targetLang: String,
        defaultBoard: String, defaultYear: String, part: Int, total: Int
    ): String {
        val typeValue = when (targetLang) {
            "English" -> "english"
            "संस्कृत" -> "sanskrit"
            else -> "hindi"
        }
        return """
            आप एक वरिष्ठ परीक्षा प्रश्न विश्लेषक, संपादक और अनुवादक हैं। OCR टेक्स्ट से केवल 100% प्रामाणिक प्रश्न निकालें।
            विषय: \${subject.name}
            लक्ष्य भाषा: \$targetLang
            डिफ़ॉल्ट बोर्ड: \$defaultBoard
            डिफ़ॉल्ट वर्ष: \$defaultYear
            प्रसंस्करण भाग: \$part / \$total

            सख्त नियम:
            1. केवल प्रामाणिक प्रश्न निकालें।
            2. भाषा नीति:
               - यदि लक्ष्य भाषा 'हिंदी' है: अंग्रेजी का अनुवाद मानक हिंदी में करें।
               - अपवाद: यदि प्रश्न संस्कृत व्याकरण या श्लोक का है, तो अनिवार्य रूप से संस्कृत में रखें।
               - यदि लक्ष्य भाषा 'English' है: सब कुछ शुद्ध English में रखें।
               - यदि लक्ष्य भाषा 'संस्कृत' है: सब कुछ शुद्ध संस्कृत में रखें।
               - वर्तनी और व्याकरण सुधारें। अपठनीय प्रश्नों को छोड़ दें।
            3. बोर्ड और वर्ष: बोर्ड में "\$defaultBoard" और वर्ष में "\$defaultYear" का उपयोग करें। प्रश्न के अंत में '[बोर्ड वर्ष]' बैज लगाएँ।
            4. सुमेलित कीजिए: HTML तालिका प्रयोग करें:
               <table border='1' cellpadding='6' style='border-collapse:collapse; width:100%; text-align:left; margin:8px 0;'><tr style='background-color:#2a2a2a;'><th>सूची-I</th><th>सूची-II</th></tr><tr><td>(1) मद A</td><td>(a) मद 1</td></tr></table>
               विकल्प: 1-(b), 2-(a) शैली।
            5. उत्तर-लीक और गिवअवे वर्ष हटाएँ। चारों विकल्प अद्वितीय हों।
            6. डेटा स्कीमा:
               - "topic": "\${subject.topic}"
               - "type": "\$typeValue"
               - "ans": 0, 1, 2, या 3 (Integer)
               - आउटपुट केवल शुद्ध JSON Array हो। कोई मार्कडाउन नहीं।

            प्रारूप:
            [
              {
                "topic": "\${subject.topic}",
                "type": "\$typeValue",
                "year": "2021",
                "board": "UP PGT",
                "exam": "UP PGT 2021",
                "q": "प्रश्न पाठ [UP PGT 2021]",
                "options": ["Option A", "Option B", "Option C", "Option D"],
                "ans": 0,
                "exp": "विस्तृत व्याख्या।"
              }
            ]

            OCR Text:
            \$text
        """.trimIndent()
    }

    private fun callGemini(prompt: String): List<Question> {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=\$apiKey"
        val body = JSONObject().put("contents", JSONArray().put(
            JSONObject().put("parts", JSONArray().put(JSONObject().put("text", prompt)))
        )).toString()

        val req = Request.Builder()
            .url(url)
            .post(body.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()

        return try {
            http.newCall(req).execute().use { r ->
                if (!r.isSuccessful) return emptyList()
                val resp = JSONObject(r.body!!.string())
                var rawJson = resp.optJSONArray("candidates")?.optJSONObject(0)
                    ?.optJSONObject("content")?.optJSONArray("parts")
                    ?.optJSONObject(0)?.optString("text")?.trim() ?: return emptyList()

                rawJson = rawJson.replace("```json", "").replace("```", "").trim()
                val start = rawJson.indexOf('[')
                val end = rawJson.lastIndexOf(']')
                if (start == -1 || end == -1) return emptyList()
                rawJson = rawJson.substring(start, end + 1)

                val jsonArray = JSONArray(rawJson)
                val list = mutableListOf<Question>()
                val json = Json { ignoreUnknownKeys = true }
                for (i in 0 until jsonArray.length()) {
                    try {
                        list.add(json.decodeFromString<Question>(jsonArray.getJSONObject(i).toString()))
                    } catch (_: Exception) {}
                }
                list
            }
        } catch (e: Exception) { emptyList() }
    }
}
