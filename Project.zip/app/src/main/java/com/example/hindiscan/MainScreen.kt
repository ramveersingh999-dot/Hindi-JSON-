package com.example.hindiscan

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    state: ScanUiState, apiKey: String, subjects: List<Subject>,
    onTabSelected: (AppTab) -> Unit, onStartScan: () -> Unit,
    onSaveKey: (String) -> Unit, onRemoveKey: () -> Unit,
    onProcess: (String, Subject, String, String, String) -> Unit,
    onExportPacks: () -> Unit, onAddSubject: (Subject) -> Unit
) {
    var showSettings by remember { mutableStateOf(false) }
    var keyInput by remember { mutableStateOf(apiKey) }
    var selectedSubject by remember { mutableStateOf(subjects.first()) }
    var selectedLang by remember { mutableStateOf("हिंदी") }
    var boardInput by remember { mutableStateOf("UP PGT") }
    var yearInput by remember { mutableStateOf("2024") }
    var pastedText by remember { mutableStateOf("") }
    var showAddSubjectDialog by remember { mutableStateOf(false) }
    var subjectDropdownExpanded by remember { mutableStateOf(false) }
    var langDropdownExpanded by remember { mutableStateOf(false) }

    if (showSettings) {
        AlertDialog(
            onDismissRequest = { showSettings = false },
            title = { Text("API Key सेटिंग्स", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = keyInput, onValueChange = { keyInput = it },
                        label = { Text("Gemini API Key") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth(), singleLine = true
                    )
                }
            },
            confirmButton = { Button(onClick = { onSaveKey(keyInput.trim()); showSettings = false }) { Text("सेव करें") } },
            dismissButton = {
                if (apiKey.isNotBlank()) {
                    TextButton(onClick = { keyInput = ""; onRemoveKey(); showSettings = false }) {
                        Text("हटाएँ", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        )
    }

    if (showAddSubjectDialog) {
        var newSubName by remember { mutableStateOf("") }
        var newSubTopic by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showAddSubjectDialog = false },
            title = { Text("नया विषय जोड़ें") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = newSubName, onValueChange = { newSubName = it }, label = { Text("विषय का नाम") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(value = newSubTopic, onValueChange = { newSubTopic = it }, label = { Text("Topic Tag") }, modifier = Modifier.fillMaxWidth())
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newSubName.isNotBlank()) {
                        val sub = Subject(newSubName, if (newSubTopic.isBlank()) newSubName else newSubTopic, "hindi")
                        onAddSubject(sub)
                        selectedSubject = sub
                        showAddSubjectDialog = false
                    }
                }) { Text("जोड़ें") }
            },
            dismissButton = { TextButton(onClick = { showAddSubjectDialog = false }) { Text("रद्द करें") } }
        )
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(8.dp), color = MaterialTheme.colorScheme.primaryContainer, modifier = Modifier.padding(end = 10.dp)) {
                            Text("ह", modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                        Column {
                            Text("HindiScan", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                            Text("स्कैन, शुद्ध हिंदी, प्रामाणिक JSON पैक", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                actions = {
                    IconButton(onClick = { showSettings = true }) {
                        Icon(Icons.Default.Key, contentDescription = "API Key", tint = if (apiKey.isNotBlank()) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surface)
            )
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.surface).padding(4.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                AppTab.values().forEach { tab ->
                    val isSelected = state.currentTab == tab
                    Box(
                        modifier = Modifier.weight(1f).clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.primary else Color.Transparent)
                            .clickable { onTabSelected(tab) }.padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = if (tab == AppTab.LIBRARY) "संग्रह \${state.questions.size}" else tab.title,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.Black else MaterialTheme.colorScheme.onSurface,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(Modifier.height(14.dp))

            when (state.currentTab) {
                AppTab.SCAN -> {
                    Column(Modifier.verticalScroll(rememberScrollState())) {
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("दस्तावेज़", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Surface(
                                    modifier = Modifier.fillMaxWidth().border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp)).clickable { onStartScan() }.padding(20.dp),
                                    color = Color.Transparent
                                ) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Default.UploadFile, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(36.dp))
                                        Spacer(Modifier.height(8.dp))
                                        Text("PDF, फ़ोटो या पाठ फ़ाइल छोड़ें", fontWeight = FontWeight.Medium)
                                        Text("अक्षर-पढ़ना इसी डिवाइस पर ऑफ़लाइन होता है।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Spacer(Modifier.height(12.dp))
                                        Button(onClick = { onStartScan() }) { Text("फ़ाइल चुनें / कैमरा") }
                                    }
                                }
                                if (state.pendingUris != null) {
                                    Spacer(Modifier.height(8.dp))
                                    Text("✓ \${state.pendingUris.size} पेज चयनित", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                }
                                Spacer(Modifier.height(14.dp))
                                Text("या पाठ चिपकाएँ", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.height(4.dp))
                                OutlinedTextField(
                                    value = pastedText, onValueChange = { pastedText = it },
                                    placeholder = { Text("OCR पाठ या पहले बना JSON पैक यहाँ डालें…") },
                                    modifier = Modifier.fillMaxWidth().height(110.dp), shape = RoundedCornerShape(8.dp)
                                )
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("विषय और परीक्षा", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Box {
                                    OutlinedTextField(
                                        value = selectedSubject.name, onValueChange = {}, readOnly = true, label = { Text("विषय") },
                                        trailingIcon = { IconButton(onClick = { subjectDropdownExpanded = true }) { Icon(Icons.Default.ArrowDropDown, contentDescription = null) } },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    DropdownMenu(expanded = subjectDropdownExpanded, onDismissRequest = { subjectDropdownExpanded = false }) {
                                        subjects.forEach { sub ->
                                            DropdownMenuItem(text = { Text(sub.name) }, onClick = { selectedSubject = sub; subjectDropdownExpanded = false })
                                        }
                                    }
                                }

                                Box {
                                    OutlinedTextField(
                                        value = selectedLang, onValueChange = {}, readOnly = true, label = { Text("OCR / लक्ष्य भाषा") },
                                        trailingIcon = { IconButton(onClick = { langDropdownExpanded = true }) { Icon(Icons.Default.ArrowDropDown, contentDescription = null) } },
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                    DropdownMenu(expanded = langDropdownExpanded, onDismissRequest = { langDropdownExpanded = false }) {
                                        listOf("हिंदी", "English", "संस्कृत").forEach { lang ->
                                            DropdownMenuItem(text = { Text(lang) }, onClick = { selectedLang = lang; langDropdownExpanded = false })
                                        }
                                    }
                                }

                                OutlinedTextField(value = boardInput, onValueChange = { boardInput = it }, label = { Text("बोर्ड (उदा. UP PGT)") }, modifier = Modifier.fillMaxWidth())
                                OutlinedTextField(value = yearInput, onValueChange = { yearInput = it }, label = { Text("वर्ष (उदा. 2024)") }, modifier = Modifier.fillMaxWidth())

                                TextButton(onClick = { showAddSubjectDialog = true }) { Text("▶ नया विषय जोड़ें") }
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("जाँच", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(8.dp))
                                if (apiKey.isBlank()) {
                                    Surface(color = MaterialTheme.colorScheme.error.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                        Text("ⓘ API कुंजी नहीं है। ऊपर ⚙ से Gemini API Key दर्ज करें।", modifier = Modifier.padding(10.dp), color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                                    }
                                    Spacer(Modifier.height(10.dp))
                                }

                                Button(
                                    onClick = { onProcess(pastedText, selectedSubject, selectedLang, boardInput, yearInput) },
                                    enabled = !state.isProcessing && (apiKey.isNotBlank() || pastedText.isNotBlank()),
                                    modifier = Modifier.fillMaxWidth().height(50.dp), shape = RoundedCornerShape(8.dp)
                                ) {
                                    Text(if (state.isProcessing) state.progressMsg.ifBlank { "प्रोसेसिंग…" } else "पढ़ें और प्रश्न जाँचें", fontWeight = FontWeight.Bold)
                                }

                                if (state.isProcessing) {
                                    Spacer(Modifier.height(10.dp))
                                    LinearProgressIndicator(Modifier.fillMaxWidth())
                                }

                                state.error?.let { err -> Spacer(Modifier.height(10.dp)); Text("त्रुटि: \$err", color = MaterialTheme.colorScheme.error) }
                                state.savedMsg?.let { msg -> Spacer(Modifier.height(10.dp)); Text("✓ \$msg", color = MaterialTheme.colorScheme.primary) }
                            }
                        }

                        Spacer(Modifier.height(14.dp))

                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("क्या तय है", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Text("1. केवल स्रोत के प्रामाणिक प्रश्न। कोई बनावटी प्रश्न नहीं।", style = MaterialTheme.typography.bodySmall)
                                Text("2. वर्तनी, व्याकरण और शब्द AI से सुधरेंगे।", style = MaterialTheme.typography.bodySmall)
                                Text("3. चार अलग विकल्प, उत्तर-लीक नहीं, और HTML तालिका।", style = MaterialTheme.typography.bodySmall)
                                Text("4. पैक में UTF-8 JSON, मास्टर फ़ाइल, और ZIP।", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }

                AppTab.LIBRARY -> {
                    Column(Modifier.fillMaxSize()) {
                        Text("सत्यापित संग्रह (\${state.questions.size} प्रश्न)", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        if (state.questions.isEmpty()) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                Text("अभी कोई प्रश्न नहीं है। 'स्कैन' से शुरू करें।", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        } else {
                            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                state.questions.forEachIndexed { i, q ->
                                    Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                                        Column(Modifier.padding(12.dp)) {
                                            Text("Q\${i + 1} • \${q.board} \${q.year} (\${q.topic})", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                                            Spacer(Modifier.height(4.dp))
                                            Text(q.q, fontWeight = FontWeight.Medium)
                                            Spacer(Modifier.height(4.dp))
                                            q.options.forEachIndexed { oIdx, opt ->
                                                Text("\${('A' + oIdx)}. \$opt \${if (oIdx == q.ans) "✓" else ""}", style = MaterialTheme.typography.bodySmall)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                AppTab.PACKS -> {
                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
                        Text("JSON पैक्स व आर्काइव", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(10.dp))
                        Card(modifier = Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
                            Column(Modifier.padding(16.dp)) {
                                Text("कुल तैयार प्रश्न: \${state.questions.size}", fontWeight = FontWeight.Bold)
                                Spacer(Modifier.height(12.dp))
                                Button(onClick = onExportPacks, enabled = state.questions.isNotEmpty(), modifier = Modifier.fillMaxWidth().height(48.dp)) {
                                    Text("Download Complete Packs (JSON + ZIP)")
                                }
                            }
                        }
                        Spacer(Modifier.height(14.dp))
                        Text("Master JSON Preview", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Surface(color = Color.Black, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                            SelectionContainer {
                                Text(
                                    text = if (state.rawJson.isNotBlank()) state.rawJson.take(3000) else "कोई डेटा नहीं है।",
                                    modifier = Modifier.padding(12.dp).verticalScroll(rememberScrollState()),
                                    color = Color(0xFF81C784), fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
