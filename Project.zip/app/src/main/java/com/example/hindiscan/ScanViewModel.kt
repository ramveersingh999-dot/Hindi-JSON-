package com.example.hindiscan

import android.app.Activity
import android.app.Application
import android.content.Intent
import android.net.Uri
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.mlkit.document.scanner.GmsDocumentScannerOptions
import com.google.android.gms.mlkit.document.scanner.GmsDocumentScanning
import com.google.android.gms.mlkit.document.scanner.GmsDocumentScanningResult
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

data class ScanUiState(
    val isProcessing: Boolean = false,
    val progressMsg: String = "",
    val questions: List<Question> = emptyList(),
    val rawJson: String = "",
    val error: String? = null,
    val savedMsg: String? = null,
    val pendingUris: List<Uri>? = null,
    val currentTab: AppTab = AppTab.SCAN
)

class ScanViewModel(app: Application) : AndroidViewModel(app) {
    private val ocr = MultiScriptOcr(app)
    val store = AppStore(app)
    private val _state = MutableStateFlow(ScanUiState())
    val state = _state.asStateFlow()

    fun setTab(tab: AppTab) { _state.value = _state.value.copy(currentTab = tab) }

    fun startScanner(activity: Activity, launch: (IntentSenderRequest) -> Unit) {
        val options = GmsDocumentScannerOptions.Builder()
            .setGalleryImportAllowed(true)
            .setPageLimit(150)
            .setResultFormats(GmsDocumentScannerOptions.RESULT_FORMAT_JPEG, GmsDocumentScannerOptions.RESULT_FORMAT_PDF)
            .setScannerMode(GmsDocumentScannerOptions.SCANNER_MODE_FULL)
            .build()
        GmsDocumentScanning.getClient(options).getStartScanIntent(activity)
            .addOnSuccessListener { launch(IntentSenderRequest.Builder(it).build()) }
            .addOnFailureListener { _state.value = _state.value.copy(error = "स्कैनर आरंभ विफल: \${it.message}") }
    }

    fun onScanResult(data: Intent?) {
        val result = GmsDocumentScanningResult.fromActivityResultIntent(data) ?: return
        val uris = mutableListOf<Uri>()
        result.pages?.forEach { uris.add(it.imageUri) }
        result.pdf?.let { uris.add(it.uri) }
        if (uris.isNotEmpty()) _state.value = _state.value.copy(pendingUris = uris)
    }

    fun processDirect(pastedText: String, subject: Subject, targetLang: String, board: String, year: String) {
        viewModelScope.launch {
            _state.value = _state.value.copy(isProcessing = true, progressMsg = "टेक्स्ट का विश्लेषण चालू है…", error = null)
            try {
                var fullText = pastedText.trim()
                val uris = _state.value.pendingUris
                if (uris != null && uris.isNotEmpty()) {
                    val sb = StringBuilder()
                    for ((i, uri) in uris.withIndex()) {
                        _state.value = _state.value.copy(progressMsg = "OCR पृष्ठ (\${i + 1}/\${uris.size})…")
                        sb.append(ocr.recognize(uri)).append("\n\n")
                    }
                    fullText = if (fullText.isNotBlank()) "\$fullText\n\n\$sb" else sb.toString()
                }

                if (fullText.isBlank()) {
                    _state.value = _state.value.copy(isProcessing = false, error = "कृपया दस्तावेज़ स्कैन करें या टेक्स्ट चिपकाएँ।")
                    return@launch
                }

                _state.value = _state.value.copy(progressMsg = "AI विशेषज्ञ सत्यापन व शुद्धिकरण कर रहा है…")
                val extractor = HindiQuestionExtractor(store.getKey())
                val newQuestions = extractor.extract(fullText, subject, targetLang, board, year)

                if (newQuestions.isEmpty()) {
                    _state.value = _state.value.copy(isProcessing = false, error = "कोई मान्य प्रामाणिक प्रश्न नहीं मिला।")
                    return@launch
                }

                val allCombined = (_state.value.questions + newQuestions).distinctBy { it.q.trim().lowercase() }
                val json = Json { prettyPrint = true; encodeDefaults = true; prettyPrintIndent = "  " }
                val jsonStr = json.encodeToString(allCombined)

                _state.value = _state.value.copy(
                    isProcessing = false, progressMsg = "", questions = allCombined,
                    rawJson = jsonStr, pendingUris = null, currentTab = AppTab.LIBRARY,
                    savedMsg = "सफलतापूर्वक \${newQuestions.size} नए प्रश्न जोड़े गए।"
                )
            } catch (e: Exception) {
                _state.value = _state.value.copy(isProcessing = false, error = e.message ?: "अज्ञात त्रुटि")
            }
        }
    }

    fun markSaved(msg: String) { _state.value = _state.value.copy(savedMsg = msg) }
    override fun onCleared() { super.onCleared(); ocr.close() }
}
