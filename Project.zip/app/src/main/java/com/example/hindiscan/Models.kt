package com.example.hindiscan

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.serialization.Serializable
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

@Serializable
data class Question(
    val topic: String = "सामान्य",
    val type: String = "hindi",
    val year: String = "",
    val board: String = "",
    val exam: String = "",
    val q: String = "",
    val options: List<String> = emptyList(),
    val ans: Int = 0,
    val exp: String = ""
)

@Serializable
data class Subject(
    val name: String,
    val topic: String,
    val type: String
)

enum class AppTab(val title: String) {
    SCAN("स्कैन"),
    LIBRARY("संग्रह"),
    PACKS("पैक")
}

class AppStore(context: Context) {
    private val prefs = EncryptedSharedPreferences.create(
        context, "secure_prefs",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
    fun getKey(): String = prefs.getString("gemini_key", "") ?: ""
    fun saveKey(key: String) = prefs.edit().putString("gemini_key", key).apply()
    fun clearKey() = prefs.edit().remove("gemini_key").apply()

    fun getSubjects(): List<Subject> {
        val default = listOf(
            Subject("हिंदी साहित्य", "हिंदी साहित्य", "hindi"),
            Subject("हिंदी व्याकरण", "हिंदी व्याकरण", "hindi"),
            Subject("संस्कृत व्याकरण", "संस्कृत व्याकरण", "hindi"),
            Subject("इतिहास (GS)", "इतिहास (GS)", "gs"),
            Subject("सामान्य ज्ञान (GK)", "सामान्य ज्ञान", "gs"),
            Subject("भूगोल", "भूगोल", "gs"),
            Subject("सामाजिक विज्ञान", "सामाजिक विज्ञान", "gs"),
            Subject("विज्ञान", "विज्ञान", "science"),
            Subject("जीव विज्ञान", "जीव विज्ञान", "science")
        )
        val customStr = prefs.getString("custom_subjects", "") ?: ""
        if (customStr.isBlank()) return default
        return try {
            val json = Json { ignoreUnknownKeys = true }
            default + json.decodeFromString<List<Subject>>(customStr)
        } catch (e: Exception) { default }
    }

    fun saveCustomSubject(subject: Subject) {
        val current = getSubjects().toMutableList()
        current.add(subject)
        val customOnly = current.drop(9)
        val json = Json { ignoreUnknownKeys = true }
        prefs.edit().putString("custom_subjects", json.encodeToString(customOnly)).apply()
    }
}
