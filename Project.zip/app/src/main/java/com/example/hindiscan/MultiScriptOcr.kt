package com.example.hindiscan

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.ParcelFileDescriptor
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

class MultiScriptOcr(private val context: Context) {
    private val devanagari = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
    private val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    suspend fun recognize(uri: Uri): String = suspendCancellableCoroutine { cont ->
        try {
            val mimeType = context.contentResolver.getType(uri)
            if (mimeType == "application/pdf") {
                kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch {
                    cont.resume(recognizePdf(uri))
                }
            } else {
                val image = InputImage.fromFilePath(context, uri)
                devanagari.process(image)
                    .addOnSuccessListener { result ->
                        if (result.text.isNotBlank()) cont.resume(result.text)
                        else {
                            latin.process(image)
                                .addOnSuccessListener { cont.resume(it.text) }
                                .addOnFailureListener { cont.resumeWithException(it) }
                        }
                    }
                    .addOnFailureListener {
                        latin.process(image)
                            .addOnSuccessListener { cont.resume(it.text) }
                            .addOnFailureListener { e -> cont.resumeWithException(e) }
                    }
            }
        } catch (e: Exception) { cont.resumeWithException(e) }
    }

    private fun recognizePdf(uri: Uri): String {
        val textBuilder = StringBuilder()
        var pfd: ParcelFileDescriptor? = null
        var renderer: PdfRenderer? = null
        try {
            pfd = context.contentResolver.openFileDescriptor(uri, "r")
            if (pfd != null) {
                renderer = PdfRenderer(pfd)
                for (i in 0 until renderer.pageCount) {
                    renderer.openPage(i).use { page ->
                        val bitmap = Bitmap.createBitmap(page.width * 2, page.height * 2, Bitmap.Config.ARGB_8888)
                        bitmap.eraseColor(Color.WHITE)
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        val image = InputImage.fromBitmap(bitmap, 0)
                        var pageDone = false
                        var pageText = ""
                        devanagari.process(image)
                            .addOnSuccessListener { r ->
                                pageText = if (r.text.isNotBlank()) r.text else ""
                                pageDone = true
                            }
                            .addOnFailureListener { pageDone = true }

                        val start = System.currentTimeMillis()
                        while (!pageDone && System.currentTimeMillis() - start < 10000) {
                            Thread.sleep(50)
                        }
                        if (pageText.isNotBlank()) textBuilder.append(pageText).append("\n\n")
                    }
                }
            }
        } catch (e: Exception) { e.printStackTrace() } finally {
            renderer?.close()
            pfd?.close()
        }
        return textBuilder.toString()
    }
    fun close() { devanagari.close(); latin.close() }
}
