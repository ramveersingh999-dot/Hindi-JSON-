package com.example.hindiscan

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val DarkBg = Color(0xFF0F1115)
val DarkCard = Color(0xFF1A1E26)
val DarkBorder = Color(0xFF282E3A)
val AccentGold = Color(0xFFE5A93C)
val AccentGoldDark = Color(0xFF3D2C0D)
val TextPrimary = Color(0xFFEDEDED)
val TextSecondary = Color(0xFF9AA0A6)
val ErrorRed = Color(0xFFE57373)

private val DarkColors = darkColorScheme(
    primary = AccentGold,
    onPrimary = Color.Black,
    primaryContainer = AccentGoldDark,
    onPrimaryContainer = AccentGold,
    surface = DarkCard,
    onSurface = TextPrimary,
    background = DarkBg,
    onBackground = TextPrimary,
    surfaceVariant = DarkBorder,
    error = ErrorRed
)

@Composable
fun HindiScanTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = DarkColors, content = content)
}
