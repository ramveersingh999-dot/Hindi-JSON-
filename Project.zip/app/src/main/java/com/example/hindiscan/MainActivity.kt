package com.example.hindiscan

import android.content.ContentValues
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class MainActivity : ComponentActivity() {
    private val vm: ScanViewModel by viewModels()

    private val launcher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == RESULT_OK) vm.onScanResult(r.data)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            HindiScanTheme {
                val state by vm.state.collectAsState()
                var currentKey by remember { mutableStateOf(vm.store.getKey()) }
                var subjectsList by remember { mutableStateOf(vm.store.getSubjects()) }

                MainScreen(
                    state = state, apiKey = currentKey, subjects = subjectsList,
                    onTabSelected = { vm.setTab(it) },
                    onStartScan = { vm.startScanner(this) { req -> launcher.launch(req) } },
                    onSaveKey = { currentKey = it; vm.store.saveKey(it) },
                    onRemoveKey = { currentKey = ""; vm.store.clearKey() },
                    onProcess = { text, sub, lang, board, year -> vm.processDirect(text, sub, lang, board, year) },
                    onExportPacks = { exportAllPacks(state.questions) },
                    onAddSubject = { sub -> vm.store.saveCustomSubject(sub); subjectsList = vm.store.getSubjects() }
                )
            }
        }
    }

    private fun exportAllPacks(allQuestions: List<Question>) {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val folderName = "HindiScan_Packs_\$timestamp"
                val totalQ = allQuestions.size
                val json = Json { prettyPrint = true; encodeDefaults = true; prettyPrintIndent = "  " }

                val filesToZip = mutableMapOf<String, String>()
                filesToZip["Master_JSON_Pack_\${totalQ}_Questions.json"] = json.encodeToString(allQuestions)

                if (totalQ > 900) {
                    val chunkSize = 850
                    allQuestions.chunked(chunkSize).forEachIndexed { index, chunk ->
                        val partNum = String.format("%02d", index + 1)
                        filesToZip["Part_\${partNum}_\${chunk.size}_Questions.json"] = json.encodeToString(chunk)
                    }
                }

                saveFilesToDownloads(folderName, filesToZip)
                withContext(Dispatchers.Main) {
                    vm.markSaved("Downloads/HindiScan_Packs/\$folderName में सेव हुआ")
                    Toast.makeText(this@MainActivity, "पैक्स सेव हो गए!", Toast.LENGTH_LONG).show()
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { Toast.makeText(this@MainActivity, "विफल: \${e.message}", Toast.LENGTH_LONG).show() }
            }
        }
    }

    private fun saveFilesToDownloads(folderName: String, files: Map<String, String>) {
        val resolver = contentResolver
        val zipFileName = "\$folderName.zip"

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val relativePath = Environment.DIRECTORY_DOWNLOADS + "/HindiScan_Packs/\$folderName"
            for ((fileName, content) in files) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                    put(MediaStore.MediaColumns.MIME_TYPE, "application/json")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                }
                resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)?.let { uri ->
                    resolver.openOutputStream(uri)?.use { it.write(content.toByteArray(Charsets.UTF_8)) }
                }
            }

            val zipValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, zipFileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/HindiScan_Packs")
            }
            resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, zipValues)?.let { zipUri ->
                resolver.openOutputStream(zipUri)?.use { os ->
                    ZipOutputStream(os).use { zos ->
                        for ((fileName, content) in files) {
                            zos.putNextEntry(ZipEntry(fileName))
                            zos.write(content.toByteArray(Charsets.UTF_8))
                            zos.closeEntry()
                        }
                    }
                }
            }
        } else {
            val baseDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "HindiScan_Packs/\$folderName")
            baseDir.mkdirs()
            for ((fileName, content) in files) File(baseDir, fileName).writeText(content, Charsets.UTF_8)

            val zipFile = File(baseDir.parentFile, zipFileName)
            ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                for ((fileName, content) in files) {
                    zos.putNextEntry(ZipEntry(fileName))
                    zos.write(content.toByteArray(Charsets.UTF_8))
                    zos.closeEntry()
                }
            }
        }
    }
}
