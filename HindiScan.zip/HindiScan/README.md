# HindiScan Pro - 5000+ Verified Question Engine

Android application for scanning Hindi/English/Sanskrit question papers, extracting verified authentic MCQs via OCR + Google Gemini AI, and exporting structured, pure UTF-8 JSON & ZIP packages.

## प्रोजेक्ट संरचना (Project Structure)
- `.github/workflows/build.yml` : ऑटोमैटिक क्लाउड APK बिल्डर (GitHub Actions)
- `settings.gradle.kts` : ग्रैडल प्रोजेक्ट कॉन्फ़िगरेशन
- `build.gradle.kts` : रूट ग्रैडल प्लगइन्स (Kotlin 1.9.22, AGP 8.4.0)
- `gradle.properties` : JVM और AndroidX मेमोरी सेटिंग्स
- `app/build.gradle.kts` : ऍप मॉड्यूल डिपेंडेंसीज़ (Compose, ML Kit, Serialization)
- `app/src/main/AndroidManifest.xml` : अनुमतियाँ और ML Kit OCR मेटाडेटा
- `app/src/main/java/com/example/hindiscan/MainActivity.kt` : सम्पूर्ण एप्लिकेशन कोड (UI, ViewModel, AI Extractor, OCR, Exporter)

## मुख्य विशेषताएं:
1. **3-टैब नेविगेशन**: स्कैन | संग्रह | पैक
2. **सख्त AI नियम**: 100% प्रामाणिक विगत वर्षों के प्रश्न, वर्तनी व व्याकरण सुधार, अपठनीय प्रश्नों का स्वतः निष्कासन
3. **भाषा नीति**: 
   - हिंदी: शुद्ध देवनागरी अनुवाद
   - संस्कृत: संस्कृत के श्लोक व व्याकरण मूल संस्कृत में सुरक्षित
   - English: शुद्ध अकादमिक अंग्रेजी
4. **सुमेलित प्रश्न**: इनलाइन HTML टेबल तालिका `<table border='1'>...</table>`
5. **पैकेजिंग**: Master JSON + 850-850 प्रश्नों के भाग + .zip आर्काइव
